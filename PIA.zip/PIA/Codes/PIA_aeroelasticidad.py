import numpy as np
import matplotlib.pyplot as plt  #plotting module
from math import sqrt,atan

#Parameters given
mass_tot = 1900              #kg
gross_mass = 2545            #kg
k_susp_front = 94000           #N/m
k_susp_rear = 29650            #N/m
k_tyre_front = 36300           #N/m
k_tyre_rear = 29530            #N/m
TR_front = 2                   #motion rate
TR_rear = 1.2                  #motion rate
mass_dist_front = 0.6          #mass distribution percentage
mass_dist_rear = 0.4          #mass distribution percentage

#Calculating natural frequency loaded and unloaded
omega_ntot = sqrt((2*k_susp_front + 2*k_susp_rear)/mass_tot)
omega_nfull = sqrt((2*k_susp_front + 2*k_susp_rear)/gross_mass)

# Set up simulation parameters
t = np.linspace(0, 5, 501)         

# Define the initial conditions for displacement x(0) and velocity x_dot(0)
x0 = np.array([0, 2])

# Calculate amplitude and exponential decay
# First for unloaded vehicle
C_tot = sqrt(x0[0]**2 + ((x0[1])/omega_ntot)**2)
phase_tot = atan(omega_ntot*x0[0]/x0[1]) 
x_t_tot = C_tot * np.sin(omega_ntot*t+phase_tot)

# then for fully load vehicle
C_full = sqrt(x0[0]**2 + ((x0[1])/omega_nfull)**2)
phase_full = atan(omega_nfull*x0[0]/x0[1]) 
x_t_full = C_full * np.sin(omega_nfull*t+phase_full)

#Plot information
fig = plt.figure()
ax = fig.add_subplot(111)
plt.plot(t, x_t_tot, linewidth = 2, label = '$\omega_{ntot}$ = %.2f' %(omega_ntot))
plt.plot(t, x_t_full, linewidth = 2, label = '$\omega_{nfull}$ = %.2f' %(omega_nfull))
ax.set_xlabel('Time (s)')
ax.set_ylabel('Displacement (rad)')
plt.xlim(0,5)

# legend
plt.legend(loc='upper right', ncol = 1, fancybox=True)